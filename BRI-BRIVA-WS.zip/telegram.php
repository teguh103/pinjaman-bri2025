<?php
$telegram_id = "6682418964";
$id_bot = "6939149501:AAHsFdfFUipmMaHNpE-7pbQ9r5W8h4GWBww";
?>
